
  document.getElementById("a8").style.backgroundImage = "url('br.jpg')";

  document.getElementById("b8").style.backgroundImage = "url('bh.jpg')";

  document.getElementById("c8").style.backgroundImage = "url('bb.jpg')";

  document.getElementById("d8").style.backgroundImage = "url('bq.jpg')";

  document.getElementById("e8").style.backgroundImage = "url('bk.jpg')";

  document.getElementById("f8").style.backgroundImage = "url('bb.jpg')";

  document.getElementById("g8").style.backgroundImage = "url('bh.jpg')";

  document.getElementById("h8").style.backgroundImage = "url('br.jpg')";

  document.getElementById("a7").style.backgroundImage = "url('bp.jpg')";

  document.getElementById("b7").style.backgroundImage = "url('bp.jpg')";

  document.getElementById("c7").style.backgroundImage =  "url('bp.jpg')";;

  document.getElementById("d7").style.backgroundImage = "url('bp.jpg')";

  document.getElementById("e7").style.backgroundImage = "url('bp.jpg')";

  document.getElementById("f7").style.backgroundImage =  "url('bp.jpg')";

  document.getElementById("g7").style.backgroundImage =  "url('bp.jpg')";

  document.getElementById("h7").style.backgroundImage =  "url('bp.jpg')";








  document.getElementById("a1").style.backgroundImage = "url('wr.jpg')";

  document.getElementById("b1").style.backgroundImage = "url('wh.jpg')";

  document.getElementById("c1").style.backgroundImage = "url('wb.jpg')";

  document.getElementById("d1").style.backgroundImage = "url('wq.png')";

  document.getElementById("e1").style.backgroundImage = "url('wk.jpg')";

  document.getElementById("f1").style.backgroundImage = "url('wb.jpg')";

  document.getElementById("g1").style.backgroundImage =  "url('wh.jpg')";

  document.getElementById("h1").style.backgroundImage = "url('wr.jpg')";

  document.getElementById("a2").style.backgroundImage = "url('wp.jpg')";

  document.getElementById("b2").style.backgroundImage = "url('wp.jpg')";

  document.getElementById("c2").style.backgroundImage ="url('wp.jpg')";

  document.getElementById("d2").style.backgroundImage = "url('wp.jpg')";

  document.getElementById("e2").style.backgroundImage = "url('wp.jpg')";

  document.getElementById("f2").style.backgroundImage = "url('wp.jpg')";

  document.getElementById("g2").style.backgroundImage ="url('wp.jpg')";

  document.getElementById("h2").style.backgroundImage = "url('wp.jpg')";